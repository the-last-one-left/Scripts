Add-Type -AssemblyName System.Windows.Forms

function ShowStartupMessage {
    $message = "This script is designed to automate several steps in your server deployments at POA. " +
               "Please note the following actions will be performed:" +
               "`n`n1. Install 'Automate' software and prompt for the location ID." +
               "`n2. If the system is a Dell, it will install and run Dell System Update (DSU)." +
               "`n3. Install and execute PSWindowsUpdate to install updates (no auto-reboot)." +
               "`n4. Prevent Server Manager from launching at startup." +
               "`n5. Disable Internet Explorer Enhanced Security Configuration for admins." +
               "`n`nEnsure that the required installers are present in the ./Installers folder and run this script as an administrator."

    $result = [System.Windows.Forms.MessageBox]::Show($message, "Deployment Automation Script", 
               [System.Windows.Forms.MessageBoxButtons]::OK, 
               [System.Windows.Forms.MessageBoxIcon]::Information)

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        Write-Host "User acknowledged the startup information."
    }
}

function Install-MSIWithParameters {
    param (
        [string]$msiPath,
        [string]$serverAddress,
        [string]$serverPass
    )
    $msiFullPath = (Resolve-Path $msiPath).Path

    if (Test-Path "C:\Windows\LTsvc") {
        Write-Host "The autmate software is already installed. Skipping installation."
        return
    }

    [System.Windows.Forms.Application]::EnableVisualStyles()
    [System.Windows.Forms.Application]::DoEvents()

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Enter Location"
    $form.Size = New-Object System.Drawing.Size(280, 150)

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Location (ID):"
    $label.AutoSize = $true
    $label.Location = New-Object System.Drawing.Point(10, 20)
    $form.Controls.Add($label)

    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Location = New-Object System.Drawing.Point(15, 50)
    $textBox.Width = 240
    $form.Controls.Add($textBox)

    $textBox.add_KeyPress({
        if (-not ([Char]::IsDigit($_.KeyChar) -or $_.KeyChar -eq [char]8)) {
            $_.Handled = $true
        }
    })

    $button = New-Object System.Windows.Forms.Button
    $button.Text = "OK"
    $button.Location = New-Object System.Drawing.Point(100, 90)
    $button.Add_Click({
        $form.Close()
    })
    $form.AcceptButton = $button
    $form.Controls.Add($button)

    $form.ShowDialog() | Out-Null
    $location = $textBox.Text

    if (-not [string]::IsNullOrWhiteSpace($location)) {
        $arguments = "/quiet /norestart SERVERADDRESS=$serverAddress SERVERPASS=$serverPass LOCATION=$location"

        Write-Host "Installing Automate MSI with specified location ID..."
        Start-Process msiexec.exe -ArgumentList "/i `"$msiFullPath`" $arguments" -Wait -NoNewWindow

        Write-Host "Installation completed."
    } else {
        Write-Host "No location ID was entered; automate installation aborted."
    }
}

function Install-SystemManagementApp {
    param (
        [string]$exePath
    )

    # Check if Dell System Update is already installed
    $dsuRegistryPath = "HKLM:\SOFTWARE\Dell\Dell System Update"

    if (Test-Path $dsuRegistryPath) {
        Write-Host "Dell System Update is already installed. Skipping installation."
        return
    }

    # Check manufacturer
    $manufacturer = Get-WmiObject -Class Win32_ComputerSystem | Select-Object -ExpandProperty Manufacturer

    if ($manufacturer -like "*Dell*") {
        Write-Host "Chassis manufacturer is Dell. Proceeding with installation..."
        
        try {
            $exeFullPath = (Resolve-Path $exePath).Path
            Write-Host "Installing the Systems Management application..."
            Start-Process -FilePath $exeFullPath -ArgumentList "/s" -Wait -NoNewWindow
            Write-Host "Installation completed."
        } catch {
            Write-Host "An error occurred during installation: $_"
        }
    } else {
        Write-Host "Chassis manufacturer is not Dell. Skipping installation."
    }
}


function CheckAndRunDSU {
    # The registry path where DSU home directory is stored
    $registryPath = "HKLM:\SOFTWARE\Dell\Dell System Update"
    $homeValueName = "Home"
    
    # Check if the DSU registry key exists
    if (Test-Path $registryPath) {
        $dsuHome = (Get-ItemProperty -Path $registryPath).$homeValueName

        if ($null -ne $dsuHome) {
            Write-Host "Dell System Update is installed."

            # Show confirmation message
            $message = "A new window will open to update firmware. A reboot will be required after it is completed." +
                       "`nSelect all firmware with 'A' and commit/install with 'C'." +
                       "`nDo you want to proceed?"

            $result = [System.Windows.Forms.MessageBox]::Show($message, "Confirmation", 
                        [System.Windows.Forms.MessageBoxButtons]::YesNo, 
                        [System.Windows.Forms.MessageBoxIcon]::Information)

            if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                Write-Host "User confirmed. Launching Dell System Update..."

                # Construct the full path to dsu.exe
                $dsuExePath = Join-Path -Path $dsuHome -ChildPath "dsu.exe"

                # Launch a new PowerShell instance with admin rights and execute DSU
                Start-Process -FilePath $dsuExePath -Verb RunAs

                Write-Host "Dell System Update launched with administrative privileges."
            } else {
                Write-Host "User canceled the operation."
            }
        } else {
            Write-Host "DSU home path not found in registry. Cannot launch DSU."
        }
    } else {
        Write-Host "Dell System Update is not installed or the registry key is missing."
    }
}


function InstallPSWindowsUpdateWithConfirmation {
    # Show confirmation message for updates
    $updateMessage = "This will launch a new window to check for and install all Windows updates." +
                     "`nDo you want to proceed? A reboot may be required after updates."

    $updateResult = [System.Windows.Forms.MessageBox]::Show($updateMessage, "Update Confirmation",
                       [System.Windows.Forms.MessageBoxButtons]::YesNo,
                       [System.Windows.Forms.MessageBoxIcon]::Information)

    if ($updateResult -eq [System.Windows.Forms.DialogResult]::Yes) {
        Write-Host "User confirmed. Launching Windows Update check and installation..."

        $psCommand = @"
if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
    Install-PackageProvider -Name NuGet -Force -Scope CurrentUser;
}

if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) {
    Install-Module -Name PSWindowsUpdate -Force -Scope CurrentUser;
}
Import-Module PSWindowsUpdate;
Get-WUInstall -AcceptAll -Install -Confirm:`$false;
Write-Host 'Updates installed. Please reboot if required.';
"@

        # Start new PowerShell session with admin rights
        Start-Process powershell -ArgumentList "-NoProfile", "-WindowStyle", "Normal", "-Command", $psCommand -Verb RunAs

        Write-Host "Windows Update process launched with administrative privileges."
    } else {
        Write-Host "User canceled the update operation."
    }
}

function DisableServerManagerOnLogon {
    $taskPath = "\Microsoft\Windows\Server Manager"
    $taskName = "ServerManager"

    if (Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction SilentlyContinue) {
        Write-Host "Disabling Server Manager auto-start task..."

        Disable-ScheduledTask -TaskPath $taskPath -TaskName $taskName

        Write-Host "Server Manager will no longer start automatically on logon."
    } else {
        Write-Host "Server Manager auto-start task not found. It may already be disabled or not exist on this system."
    }
}

function DisableIEEnhancedSecurityForAdmins {
    $adminRegistryPath = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components"
    $valueName = "IsInstalled"

    $adminKeys = @(
        "{A08C5FF3-281D-4274-9FE4-4AD3EC20F02B}",
        "{2C463AC0-255E-4C37-981A-F582BEC7476C}"
    )

    try {
        foreach ($key in $adminKeys) {
            $fullPath = Join-Path -Path $adminRegistryPath -ChildPath $key
            
            if (Test-Path $fullPath) {
                Set-ItemProperty -Path $fullPath -Name $valueName -Value 0
                Write-Host "IE Enhanced Security Configuration disabled for key: $key"
            } else {
                Write-Host "Registry path does not exist: $fullPath"
            }
        }
        Write-Host "IE Enhanced Security Configuration has been disabled for administrators."
    } catch {
        Write-Host "An error occurred while attempting to modify the registry: $_"
    }
}
function ShowEndingMessage {
    $message = "Tasks completed. Please review the console for any warnings or errors." +
               "`nMonitor the subprocesses for updates and DSU, and reboot as needed."

    [System.Windows.Forms.MessageBox]::Show($message, "Deployment Automation Script Completed",
               [System.Windows.Forms.MessageBoxButtons]::OK,
               [System.Windows.Forms.MessageBoxIcon]::Information)

    Write-Host "User notified about completion and post-execution tasks."
}

ShowStartupMessage
Install-MSIWithParameters -msiPath ".\Installers\Agent_Install.msi" `
                          -serverAddress "https://mp.pacificoffice.com" `
                          -serverPass "GyAbbxxmqOv8KATwe/g1kPQf94gt3jng"

Install-SystemManagementApp -exePath ".\Installers\Systems-Management_Application_03GC8_WN64_2.1.1.0_A00.EXE"
CheckAndRunDSU
InstallPSWindowsUpdateWithConfirmation
DisableServerManagerOnLogon
DisableIEEnhancedSecurityForAdmins
ShowEndingMessage